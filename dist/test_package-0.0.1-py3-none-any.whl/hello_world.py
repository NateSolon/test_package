def hello_world(name=None):
	if name:
		return f"Hello, {name}!"
	else:
		return "Hello, world!"